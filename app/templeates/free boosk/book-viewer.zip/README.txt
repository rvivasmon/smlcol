A Pen created at CodePen.io. You can find this one at https://codepen.io/jjcarey/pen/JKGqjK.

 Weekend Project. I wanted to build a book viewer that was browsable, searchable and show details of each individual books.